# NASSO'S BARBEARIA — protótipo do site

Este pacote contém uma primeira versão visual e interativa do site da NASSO'S BARBEARIA.

## Como abrir

1. Extraia `nassos-barbearia.zip`.
2. Abra `index.html` no navegador para visualizar a página.
3. Para editar o projeto, abra a pasta no Visual Studio Code.

## O que já está incluído

- Design responsivo para computador e celular.
- Hero cinematográfica com fallback visual.
- Seção de serviços com categorias, valores e durações informados.
- Seção institucional, galeria de referências, localização e horários.
- Animações de entrada e microinterações.
- Modal de agendamento em etapas.
- Geração de mensagem de solicitação para WhatsApp.

## Importante: agendamento ainda não é produção

O calendário nesta versão é apenas uma demonstração de interface. Os horários não vêm de uma base de dados e não são bloqueados entre clientes. O formulário prepara uma mensagem de WhatsApp, mas não cria uma reserva real.

Antes de aceitar agendamentos de clientes, conectar:
- Supabase/PostgreSQL para persistência.
- Validação atômica no backend para impedir reservas conflitantes.
- Autenticação e autorização para o painel administrativo.
- Provedor de e-mail transacional para notificações.

Não anuncie a disponibilidade do protótipo como disponibilidade real.

## Vídeo real de fundo

Coloque uma filmagem real, licenciada, de barbeiro cortando cabelo em:

`videos/hero-barber.mp4`

O componente tentará reproduzir esse arquivo automaticamente. Enquanto o arquivo não existir ou não carregar, a página exibirá uma imagem de fundo.

## Imagens

As imagens atuais são referências ilustrativas carregadas de URLs externas do Unsplash. Elas não representam necessariamente trabalhos executados pela NASSO'S BARBEARIA. Substitua-as por fotografias próprias ou por imagens licenciadas quando disponíveis.

## Publicação

Para publicar esta versão estática, você pode enviar os arquivos para um repositório GitHub e importar o projeto na Vercel. Para ativar agendamentos reais, implemente e configure o backend antes de divulgar o sistema como funcional.
